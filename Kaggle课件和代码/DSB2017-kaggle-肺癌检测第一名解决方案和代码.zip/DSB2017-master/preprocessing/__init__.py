from full_prep import full_prep,savenpy
